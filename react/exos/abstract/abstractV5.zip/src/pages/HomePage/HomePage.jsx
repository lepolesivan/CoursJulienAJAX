import React from "react";
import Header from "../../components/Header/Header";
import Jokes from "../../components/Jokes/Jokes";
import Footer from "../../components/Footer/Footer";

function HomePage() {
  return (
    <>
      <Header />
      <Jokes />
      <Footer />
    </>
  );
}

export default HomePage;
