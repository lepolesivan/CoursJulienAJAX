import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import Header from "./components/Header/Header";
import Search from "./components/Search/Search";
import CardList from "./components/CardsList/CardList";
import "./App.css";

function App() {
  const footerParts = [
    {
      title: "Abstract",
      elements: ["Start Trial", "Pricing", "Download"],
    },
    {
      title: "Resources",
      elements: ["Blog", "Help Center", "Release Notes", "Status"],
    },
    {
      title: "Community",
      elements: ["Twitter", "LinkedIn", "Facebook", "Dribbble", "Podcast"],
    },
    {
      title: "Company",
      elements: ["About Us", "Careers", "Legal", "Contact Us"],
    },
  ];

  const other = [
    "info@abstract.com",
    "© Copyright 2023",
    "Abstract Studio Design, Inc.",
    "All rights reserved",
  ];
  return (
    <>
      <Header />
      <Search />
      <CardList />
      <div>
        {footerParts.map((part) => {
          return (
            <>
              <h3>{part.title}</h3>
              <ul>
                {part.elements.map((element) => {
                  return <li>{element}</li>;
                })}
              </ul>
            </>
          );
        })}
      </div>
    </>
  );
}

export default App;
