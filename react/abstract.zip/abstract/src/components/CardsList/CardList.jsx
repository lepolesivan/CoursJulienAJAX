import React from "react";
import Card from "./Card";
import styles from "./CardList.module.css";

function CardList() {
  const cards = [
    {
      icone: "X",
      title: "Using Abstract",
      content:
        "Abstract lets you manage, version, and document your designs in one place.",
    },
    {
      icone: "X",
      title: "Manage your account",
      content:
        "Configure your account settings, such as your email, profile details, and password.",
      special: false,
    },
    {
      icone: "X",
      title: "Manage organizations, teams, and projects",
      content:
        "Use Abstract organizations, teams, and projects to organize your people and your work.",
      special: true,
    },
    {
      icone: "X",
      title: "Manage billing",
      content: "Change subscriptions and payment details.      ",
    },
    {
      icone: "X",
      title: "Authenticate to Abstract",
      content:
        "Set up and configure SSO, SCIM, and Just-in-Time provisioning.    ",
    },
    {
      icone: "X",
      title: "Abstract support",
      content: "Get in touch with a human.",
    },
  ];

  return (
    <div className={styles.cardsContainer}>
      {cards.map((card) => {
        return <Card key={card.content} card={card} />;
      })}
    </div>
  );
}

export default CardList;
