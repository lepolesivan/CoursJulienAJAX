An integration of

https://www.frontendpractice.com/projects/abstract
