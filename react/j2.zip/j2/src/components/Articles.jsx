const Articles = () => {
  return (
    <div>
      <section>
        <h2>Lorem ipsum dolor sit amet.</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere aut
          ratione ea magnam dolores, aliquid similique quae placeat natus totam
          sapiente voluptatum debitis, molestias in consequatur, amet tempore
          architecto blanditiis!
        </p>
      </section>
      <section>
        <h2>Lorem ipsum dolor sit amet.</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere aut
          ratione ea magnam dolores, aliquid similique quae placeat natus totam
          sapiente voluptatum debitis, molestias in consequatur, amet tempore
          architecto blanditiis!
        </p>
      </section>
      <section>
        <h2>Lorem ipsum dolor sit amet.</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere aut
          ratione ea magnam dolores, aliquid similique quae placeat natus totam
          sapiente voluptatum debitis, molestias in consequatur, amet tempore
          architecto blanditiis!
        </p>
      </section>
    </div>
  );
};

export default Articles;
