import MenuHomePage from "./MenuHomePage";

const Header = () => {
  return (
    <header>
      <MenuHomePage />
    </header>
  );
};

export default Header;
