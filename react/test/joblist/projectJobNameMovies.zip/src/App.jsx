import JobOffersGroup from "./components/JobOffersGroup/JobOffersGroup";
import jsonData from "./data.json";
import SearchMoviesFeature from "./components/SearchMoviesFeature/SearchMoviesFeature";
import AgeByNameFeature from "./components/AgeByNameFeature/AgeByNameFeature";

function App() {
  console.log("APP rerender");

  return (
    <>
      <JobOffersGroup data={jsonData} />
      <AgeByNameFeature />
      <SearchMoviesFeature />
    </>
  );
}

export default App;
